




void sprint(char);

void sprintln(char);

void sbegin(int);

int randomn(int, int);

int pinread();





